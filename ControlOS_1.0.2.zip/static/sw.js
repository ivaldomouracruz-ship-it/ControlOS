// ── Excellence OS — Service Worker ───────────────────────────────────────────
const CACHE_NOME = 'excellence-os-v2';

// Arquivos que serão cacheados para uso offline
const ARQUIVOS_CACHE = [
    '/',
    '/historico',
    '/static/css/style.css',
    '/static/js/app.js',
    '/static/img/logo.png',
    '/static/img/logo_perfil.png',
    '/static/img/favicon.ico',
    '/static/img/icon-192.png',
    '/static/img/icon-512.png',
    '/static/manifest.json',
    'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js'
];

// ── Instalação: baixa e cacheia todos os arquivos ─────────────────────────────
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NOME).then(cache => {
            return cache.addAll(ARQUIVOS_CACHE);
        })
    );
    self.skipWaiting();
});

// ── Ativação: remove caches antigos ───────────────────────────────────────────
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(nomes => {
            return Promise.all(
                nomes
                    .filter(nome => nome !== CACHE_NOME)
                    .map(nome => caches.delete(nome))
            );
        })
    );
    self.clients.claim();
});

// ── Interceptação de requisições ──────────────────────────────────────────────
self.addEventListener('fetch', event => {
    const url = new URL(event.request.url);

    // Requisições POST (salvar OS) sempre vão para a rede
    if (event.request.method === 'POST') {
        event.respondWith(
            fetch(event.request).catch(() => {
                // Se offline, retorna resposta indicando falha de rede
                return new Response(
                    JSON.stringify({ erro: 'offline', mensagem: 'Sem conexão. A OS será salva quando você reconectar.' }),
                    { status: 503, headers: { 'Content-Type': 'application/json' } }
                );
            })
        );
        return;
    }

    // APIs dinâmicas (buscar_cliente, buscar_ultima_os, verificar_atualizacao):
    // tenta rede primeiro, cai no cache se offline
    const ehApi = url.pathname.startsWith('/buscar') || url.pathname.startsWith('/verificar');
    if (ehApi) {
        event.respondWith(
            fetch(event.request)
                .then(resp => {
                    // Cacheia resultado fresco
                    const copia = resp.clone();
                    caches.open(CACHE_NOME).then(cache => cache.put(event.request, copia));
                    return resp;
                })
                .catch(() => caches.match(event.request))
        );
        return;
    }

    // Para tudo mais: cache primeiro, rede como fallback
    event.respondWith(
        caches.match(event.request).then(cached => {
            if (cached) return cached;
            return fetch(event.request).then(resp => {
                // Cacheia respostas bem-sucedidas
                if (resp && resp.status === 200 && resp.type !== 'opaque') {
                    const copia = resp.clone();
                    caches.open(CACHE_NOME).then(cache => cache.put(event.request, copia));
                }
                return resp;
            });
        })
    );
});

// ── Sincronização em background (quando reconectar) ───────────────────────────
self.addEventListener('sync', event => {
    if (event.tag === 'sync-os-pendentes') {
        event.waitUntil(sincronizarOSPendentes());
    }
});

async function sincronizarOSPendentes() {
    // Futura implementação: salvar OS pendentes do IndexedDB
    // quando o dispositivo reconectar à internet
    console.log('[SW] Sincronizando OS pendentes...');
}
