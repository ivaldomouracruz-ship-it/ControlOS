// ── Auto-resize para textareas (global) ──────────────────────────────────────
window.autoResize = function(el) {
    el.style.minHeight = '';
    el.style.height = 'auto';
    el.style.height = el.scrollHeight + 'px';
    el.style.minHeight = el.scrollHeight + 'px';
};

// ── Autocompletar produtos (função global, chamada via oninput no HTML) ─────────
function autocompletarProduto(input) {
    const termo = input.value.trim();
    const container = input.closest('td');
    if (!container) return;

    let lista = container.querySelector('.sugestoes-produto');
    if (!lista) {
        lista = document.createElement('div');
        lista.className = 'sugestoes-lista sugestoes-produto';
        container.appendChild(lista);
    }

    if (termo.length < 2) { lista.style.display = 'none'; return; }

    fetch('/buscar_produto?termo=' + encodeURIComponent(termo))
        .then(r => r.json())
        .then(produtos => {
            lista.innerHTML = '';
            if (!produtos.length) { lista.style.display = 'none'; return; }
            produtos.forEach(p => {
                const item = document.createElement('div');
                item.className = 'sugestao-item';
                item.textContent = p;
                const selecionar = function () {
                    input.value = p;
                    lista.style.display = 'none';
                };
                item.addEventListener('click', selecionar);
                item.addEventListener('touchend', function (e) {
                    e.preventDefault();
                    selecionar();
                });
                lista.appendChild(item);
            });
            lista.style.display = 'block';
        })
        .catch(() => { lista.style.display = 'none'; });
}

// Fecha listas ao clicar fora
document.addEventListener('click', function (e) {
    if (!e.target.closest('#tabela-produtos')) {
        document.querySelectorAll('.sugestoes-produto').forEach(l => l.style.display = 'none');
    }
});

document.addEventListener('DOMContentLoaded', function () {

// ── Antes de imprimir, força o resize em todos os textareas ──────────────────
window.addEventListener('beforeprint', function () {
    document.querySelectorAll('.passo-input, .obs-input').forEach(el => {
        el.style.minHeight = '';
        el.style.height = 'auto';
        el.style.height = el.scrollHeight + 'px';
        el.style.minHeight = el.scrollHeight + 'px';
        el.style.overflow = 'visible';
    });
});

// ── Máscara CEP ───────────────────────────────────────────────────────────────
document.getElementById('cep').addEventListener('input', function () {
    let v = this.value.replace(/\D/g, '').slice(0, 8);
    if (v.length > 5) v = v.slice(0,5) + '-' + v.slice(5);
    this.value = v;
});

// ── Máscara CNPJ ──────────────────────────────────────────────────────────────
document.getElementById('cnpj').addEventListener('input', function () {
    let v = this.value.replace(/\D/g, '').slice(0, 14);
    if (v.length > 12) v = v.slice(0,2)+'.'+v.slice(2,5)+'.'+v.slice(5,8)+'/'+v.slice(8,12)+'-'+v.slice(12);
    else if (v.length > 8) v = v.slice(0,2)+'.'+v.slice(2,5)+'.'+v.slice(5,8)+'/'+v.slice(8);
    else if (v.length > 5) v = v.slice(0,2)+'.'+v.slice(2,5)+'.'+v.slice(5);
    else if (v.length > 2) v = v.slice(0,2)+'.'+v.slice(2);
    this.value = v;
    atualizarDocumentoCliente();
});

// ── Máscara CPF ───────────────────────────────────────────────────────────────
document.getElementById('cpf').addEventListener('input', function () {
    let v = this.value.replace(/\D/g, '').slice(0, 11);
    if (v.length > 9) v = v.slice(0,3)+'.'+v.slice(3,6)+'.'+v.slice(6,9)+'-'+v.slice(9);
    else if (v.length > 6) v = v.slice(0,3)+'.'+v.slice(3,6)+'.'+v.slice(6);
    else if (v.length > 3) v = v.slice(0,3)+'.'+v.slice(3);
    this.value = v;
    atualizarDocumentoCliente();
});

// ── Máscara Celular ───────────────────────────────────────────────────────────
document.getElementById('celular').addEventListener('input', function () {
    let v = this.value.replace(/\D/g, '').slice(0, 11);
    if (v.length > 7) v = '('+v.slice(0,2)+') '+v.slice(2,3)+' '+v.slice(3,7)+'-'+v.slice(7);
    else if (v.length > 3) v = '('+v.slice(0,2)+') '+v.slice(2);
    else if (v.length > 0) v = '('+v;
    this.value = v;
});

// ── Máscara Telefone fixo ─────────────────────────────────────────────────────
document.getElementById('telefone').addEventListener('input', function () {
    let v = this.value.replace(/\D/g, '').slice(0, 10);
    if (v.length > 6) v = '('+v.slice(0,2)+') '+v.slice(2,6)+'-'+v.slice(6);
    else if (v.length > 2) v = '('+v.slice(0,2)+') '+v.slice(2);
    else if (v.length > 0) v = '('+v;
    this.value = v;
});

// ── Preenche assinatura do cliente automaticamente ───────────────────────────
document.getElementById('contato').addEventListener('input', function () {
    document.getElementById('assinatura_responsavel').value = this.value.trim();
});

// ── Preenche documento do cliente automaticamente ────────────────────────────
function atualizarDocumentoCliente() {
    const cnpj = document.getElementById('cnpj').value.trim();
    const cpf  = document.getElementById('cpf').value.trim();
    const campo = document.getElementById('assinatura_cnpj');
    if (cnpj && cpf) {
        campo.value = 'CNPJ: ' + cnpj + '  |  CPF: ' + cpf;
    } else if (cnpj) {
        campo.value = 'CNPJ: ' + cnpj;
    } else if (cpf) {
        campo.value = 'CPF: ' + cpf;
    } else {
        campo.value = '';
    }
}

// ── Autocompletar cliente ─────────────────────────────────────────────────────
const inputCliente = document.getElementById('cliente');
const listaSugestoes = document.getElementById('sugestoes-cliente');

inputCliente.addEventListener('input', function () {
    const termo = this.value.trim();
    if (termo.length < 2) {
        listaSugestoes.style.display = 'none';
        return;
    }

    fetch('/buscar_cliente?termo=' + encodeURIComponent(termo))
        .then(r => r.json())
        .then(clientes => {
            listaSugestoes.innerHTML = '';
            if (clientes.length === 0) {
                listaSugestoes.style.display = 'none';
                return;
            }
            clientes.forEach(c => {
                const item = document.createElement('div');
                item.className = 'sugestao-item';
                item.textContent = c.cliente;
                item.addEventListener('click', function () {
                    preencherCliente(c);
                    listaSugestoes.style.display = 'none';
                });
                item.addEventListener('touchend', function (e) {
                    e.preventDefault();
                    preencherCliente(c);
                    listaSugestoes.style.display = 'none';
                });
                listaSugestoes.appendChild(item);
            });
            listaSugestoes.style.display = 'block';
        });
});

document.addEventListener('click', function (e) {
    if (!inputCliente.contains(e.target) && !listaSugestoes.contains(e.target)) {
        listaSugestoes.style.display = 'none';
    }
});

function preencherCliente(c) {
    document.getElementById('cliente').value        = c.cliente || '';
    document.getElementById('endereco').value       = c.endereco || '';
    document.getElementById('cep').value            = c.cep || '';
    document.getElementById('municipio').value      = c.municipio || '';
    document.getElementById('estado').value         = c.estado || '';
    document.getElementById('cnpj').value           = c.cnpj || '';
    document.getElementById('cpf').value            = c.cpf || '';
    document.getElementById('contato').value        = c.contato || '';
    document.getElementById('celular').value        = c.celular || '';
    document.getElementById('telefone').value       = c.telefone || '';
    document.getElementById('assinatura_responsavel').value = c.contato || '';
    atualizarDocumentoCliente();

    fetch('/buscar_ultima_os?cliente=' + encodeURIComponent(c.cliente))
        .then(r => r.json())
        .then(os => {
            if (!os || !os.id) return;
            if (os.tecnico) document.querySelector('input[name="tecnico"]').value = os.tecnico;
            document.querySelectorAll('input[name="pragas"]').forEach(cb => {
                cb.checked = os.pragas && os.pragas.includes(cb.value);
            });
            ['passo1','passo2','passo3','passo4','passo5'].forEach(p => {
                const el = document.querySelector('textarea[name="' + p + '"]');
                if (el && os[p]) { el.value = os[p]; autoResize(el); }
            });
            if (os.tipo_servico) {
                document.querySelector('input[name="tipo_servico"]').value = os.tipo_servico;
            }
            const descs = os.produto_desc ? os.produto_desc.split('|') : [];
            const comps = os.produto_comp ? os.produto_comp.split('|') : [];
            const veis  = os.produto_vei  ? os.produto_vei.split('|')  : [];
            const qtds  = os.produto_qtd  ? os.produto_qtd.split('|')  : [];
            const tabela = document.getElementById('tabela-produtos');
            tabela.innerHTML = '';
            descs.forEach((desc, i) => {
                if (!desc.trim()) return;
                tabela.appendChild(criarLinhaProduto(desc, comps[i]||'', veis[i]||'', qtds[i]||''));
            });
            while (tabela.rows.length < 3) tabela.appendChild(criarLinhaProduto());
        });
}

// ── Corrigir labels nas linhas existentes ─────────────────────────────────────
(function corrigirLabels() {
    const labels = ['Descrição', 'Composição', 'Veículo', 'Qtd'];
    document.querySelectorAll('#tabela-produtos tr').forEach(tr => {
        tr.querySelectorAll('td').forEach((td, i) => {
            if (!td.getAttribute('data-label') && labels[i]) {
                td.setAttribute('data-label', labels[i]);
            }
        });
    });
})();

}); // fim DOMContentLoaded

// ── Criar linha da tabela de produtos (global) ────────────────────────────────
function criarLinhaProduto(desc, comp, vei, qtd, removivel) {
    desc = desc || ''; comp = comp || ''; vei = vei || ''; qtd = qtd || '';
    const linha = document.createElement('tr');

    const tdDesc = document.createElement('td');
    tdDesc.setAttribute('data-label', 'Descri\u00e7\u00e3o');
    tdDesc.style.position = 'relative';
    const inDesc = document.createElement('input');
    inDesc.type = 'text'; inDesc.name = 'produto_desc';
    inDesc.autocomplete = 'off'; inDesc.value = desc;
    inDesc.setAttribute('oninput', 'autocompletarProduto(this)');
    tdDesc.appendChild(inDesc);

    const tdComp = document.createElement('td');
    tdComp.setAttribute('data-label', 'Composi\u00e7\u00e3o');
    const inComp = document.createElement('input');
    inComp.type = 'text'; inComp.name = 'produto_comp'; inComp.value = comp;
    tdComp.appendChild(inComp);

    const tdVei = document.createElement('td');
    tdVei.setAttribute('data-label', 'Ve\u00edculo');
    const inVei = document.createElement('input');
    inVei.type = 'text'; inVei.name = 'produto_vei'; inVei.value = vei;
    tdVei.appendChild(inVei);

    const tdQtd = document.createElement('td');
    tdQtd.setAttribute('data-label', 'Qtd');
    const inQtd = document.createElement('input');
    inQtd.type = 'text'; inQtd.name = 'produto_qtd'; inQtd.value = qtd;
    tdQtd.appendChild(inQtd);

    linha.appendChild(tdDesc);
    linha.appendChild(tdComp);
    linha.appendChild(tdVei);
    linha.appendChild(tdQtd);

    const tdRemover = document.createElement('td');
    tdRemover.className = 'td-remover';
    if (removivel) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn-remover-linha';
        btn.textContent = '\u2715';
        btn.title = 'Remover linha';
        btn.addEventListener('click', function() { linha.remove(); });
        tdRemover.appendChild(btn);
    }
    linha.appendChild(tdRemover);

    return linha;
}

// ── Adicionar linha (global) ──────────────────────────────────────────────────
window.adicionarLinhaProduto = function() {
    document.getElementById('tabela-produtos').appendChild(criarLinhaProduto('', '', '', '', true));
}



// ── Limpar tudo (escopo global) ───────────────────────────────────────────────
window.limparTudo = function() {
    if (confirm('Deseja limpar todos os campos?')) {
        document.getElementById('form-os').reset();
        document.querySelectorAll('.passo-input, .obs-input').forEach(el => {
            el.style.height = 'auto';
            el.style.minHeight = '';
        });
        const listaSugestoes = document.getElementById('sugestoes-cliente');
        if (listaSugestoes) listaSugestoes.style.display = 'none';
    }
}

// ── Nova OS (escopo global) ───────────────────────────────────────────────────
window.novaOS = function() {
    if (confirm('Deseja iniciar uma nova OS? O formulário será limpo.')) {
        window.location.href = '/';
    }
}

// ── Gerar PDF (escopo global) ─────────────────────────────────────────────────
window.gerarPDF = function() {
    const ehCelular = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

    if (!ehCelular) {
        // PC: abre diálogo nativo de impressão/salvar PDF do Windows
        window.print();
        return;
    }

    // Celular: gera PDF via html2pdf.js
    if (typeof html2pdf === 'undefined') {
        window.print();
        return;
    }

    const spinner = document.getElementById('spinner-pdf');
    if (spinner) spinner.classList.add('ativo');

    document.querySelectorAll('.passo-input, .obs-input').forEach(el => {
        el.style.minHeight = '';
        el.style.height = 'auto';
        el.style.height = el.scrollHeight + 'px';
        el.style.overflow = 'visible';
    });

    const elemento = document.querySelector('.pagina');
    const nomeArquivo = 'OS_' + (document.querySelector('.numero-valor')?.textContent?.replace('/', '-') || 'excellence') + '.pdf';
    const botoes = document.querySelector('.botoes-acao');
    if (botoes) botoes.style.visibility = 'hidden';

    const opcoes = {
        margin:      [6, 6, 6, 6],
        filename:    nomeArquivo,
        image:       { type: 'jpeg', quality: 0.95 },
        html2canvas: { scale: 2, useCORS: true, logging: false },
        jsPDF:       { unit: 'mm', format: 'a4', orientation: 'portrait' },
        pagebreak:   { mode: ['avoid-all', 'css', 'legacy'] }
    };

    html2pdf().set(opcoes).from(elemento).save().then(() => {
        if (botoes) botoes.style.visibility = '';
        if (spinner) spinner.classList.remove('ativo');
    }).catch(() => {
        if (botoes) botoes.style.visibility = '';
        if (spinner) spinner.classList.remove('ativo');
        window.print();
    });
}

// ── Verificar atualização ao abrir ───────────────────────────────────────────
window.addEventListener('load', function () {
    fetch('/verificar_atualizacao')
        .then(r => r.json())
        .then(data => {
            if (data.atualizar) {
                const aviso = document.getElementById('aviso-atualizacao');
                const versaoNova = document.getElementById('versao-nova');
                if (aviso) {
                    versaoNova.textContent = data.versao;
                    aviso.style.display = 'flex';
                }
            }
        })
        .catch(() => {});
});

window.instalarAtualizacao = function() {
    if (confirm('Deseja instalar a atualização agora? O programa será reiniciado automaticamente.')) {
        fetch('/atualizar', { method: 'POST' })
            .then(r => r.json())
            .then(data => {
                if (data.sucesso) {
                    alert('✅ Atualização baixada! O programa será reiniciado.');
                } else {
                    alert('❌ Erro ao atualizar. Tente novamente mais tarde.');
                }
            });
    }
}
